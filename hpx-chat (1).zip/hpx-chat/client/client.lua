nuiOpen = false
loaded = false
playerData = {}
userInfo = ""
haveMask = false
firstLoad = true

RegisterNetEvent('chatMessage')
RegisterNetEvent('chat:addSuggestions')
RegisterNetEvent('chat:addSuggestion')
RegisterNetEvent('chat:addMessage')
RegisterNetEvent('_chat:messageEntered')
RegisterNetEvent('chat:clear')

RegisterCommand('testaddmessage',function()
  TriggerEvent('chat:addMessage', {
    color = { 255, 0, 0},
    multiline = true,
    args = { "staff", "This is a test message" }
  })

end)

local addMessage = function(message)
  if type(message) == 'string' then
    message = {
      args = { message }
    }
  end
  SendNUIMessage({
    type = 'PA_CHATMESSAGE',
    message = message
  })
end
exports('addMessage', addMessage)
AddEventHandler('chat:addMessage', addMessage)

loop = true
Citizen.CreateThread(function()
  while loop do
       Citizen.Wait(1)
       if NetworkIsPlayerActive(PlayerId()) then 
        TriggerCallback('getPlayerInfo', function(data)
          if data then
              loop = false
              userInfo = data
          end
        end)

      end 
  end
end)


AddEventHandler('chatMessage', function(author, color, text)
    Wait(500)
    local args = { text }
    if author ~= "" then
        table.insert(args, 1, author)
    end
    SendNUIMessage({
      type = 'PA_CHATMESSAGE',
      timeOut = Config.timeOut,
      message = {
        color = color,
        args = args,
        text = text
      }
    })
end)


AddEventHandler('chat:clear', function(name)
  SendNUIMessage({
    type = 'PA_CLEAR'
  })
end)


AddEventHandler('chat:addSuggestion', function(name, help, params)
  addSuggestion(name, help, params)
end)


AddEventHandler('chat:addSuggestions', function(suggestions)
    for _, suggestion in ipairs(suggestions) do
      SendNUIMessage({
        type = 'PA_ADDSUGGESTION',
        suggestion = suggestion
      })
    end
end)
  

function addSuggestion(name, help, params)
  SendNUIMessage({
    type = 'PA_SUGGESTION_ADD',
    suggestion = {
      name = name,
      help = help,
      params = params or nil
    }
  })
end

exports('addSuggestion', addSuggestion)



local function refreshCommands()
    if GetRegisteredCommands then
      local registeredCommands = GetRegisteredCommands()
      local suggestions = {}
      for _, command in ipairs(registeredCommands) do
          if IsAceAllowed(('command.%s'):format(command.name)) and command.name ~= 'toggleChat' then
              table.insert(suggestions, {
                  name = '/' .. command.name,
                  help = '',
                  params = command.params or nil
                })
          end
      end
      TriggerEvent('chat:addSuggestions', suggestions)
    end
  end


  AddEventHandler('onClientResourceStart', function(resName)
    Wait(500)
  
    refreshCommands()
  end)
  
  AddEventHandler('onClientResourceStop', function(resName)
    Wait(500)
  
    refreshCommands()
  end)
  
RegisterNUICallback('load', function(data, cb)
    TriggerServerEvent('chat:init',firstLoad);
    firstLoad = false
    loaded = true
    refreshCommands()
end)

RegisterNUICallback('close', function(data, cb)
    SetNuiFocus(false, false)
    SetTextChatEnabled(true)
    nuiOpen = false
end)


RegisterNUICallback('send', function(data, cb)
  nuiOpen = false
  SetNuiFocus(false)

    local id = PlayerId()
    local r, g, b = 0, 0x99, 255

    if Config.startMarker == "" then 
      ExecuteCommand(data.text:sub(1))
    end

    if data.text:sub(1, 1) == Config.startMarker then
      ExecuteCommand(data.text:sub(2))
    else
      TriggerServerEvent('_chat:messageEntered', GetPlayerName(id), { r, g, b }, data.text, "all")
    end

end)

RegisterNUICallback('close', function(data, cb)
  SetNuiFocus(false, false)
  nuiOpen = false
end)



Citizen.CreateThread(function()
    while true do
        if not nuiOpen then
            if IsControlPressed(0, 245) then
                SetNuiFocus(true, true)  
                SetTextChatEnabled(false)
                nuiOpen = true
                SendNUIMessage({
                    type = 'PA_OPEN',
                    userInfo = userInfo,
                    timeOut = Config.timeOut
                })
            end
        end  

        if loaded then 
          if Config.mask then
            if GetPedDrawableVariation(PlayerPedId(), 1) == 0 then
                haveMask = false
            else
                haveMask = true
            end
          else
            haveMask = false
          end

            local forceHide = IsScreenFadedOut() or IsPauseMenuActive()
            SendNUIMessage({
                type = 'PA_STATE',
                state = forceHide,
                mask = haveMask,
                timeOut = Config.timeOut
            })
        end

        Wait(0)
      end
end)

