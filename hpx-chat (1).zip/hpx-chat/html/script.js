menuOpen = false;
userInfo = "Unknown User [ID: 0]";
color = "rgb(255,255,255)";
setData = false;
var messageArr = {}
timeOut = 5000;

window.addEventListener("message", function (e) {
    e = e.data
    switch (e.type) {
      case "PA_CHATMESSAGE":
        return chatMessage(e)
    case "PA_OPEN":
        return open(e)
    case "PA_STATE":
        return state(e)
    case "PA_ADDSUGGESTION":
        return addSuggestions(e)
    case "PA_SUGGESTION_ADD":
        return newSuggestion(e)
    case "PA_CLEAR":
      default:
        return;
    }
});




var args = {
    state : "rgb(100,100,100)",
    bill : "rgb(255,140,0)",
    dispatch : "rgb(50,108,159)",
    system : "red",
    status : "rgb(147,62,47)",
    staff : "rgb(255,255,255)",
    ooc : "rgb(50,108,159)",
    me : "rgb(255,255,255)",
    feed : "rgb(255,255,255)",
}

function chatMessage(e){
    color = args[e.message.args[0].toLowerCase()];

    if (e.message.color === undefined) {
        if (color === undefined) {
            color = args['staff'];
        }
    }

    if (e.message.args[0].toLowerCase=== "ooc" ) {
        color = args['ooc'];
        return;
    }else{
        color = args[e.message.args[0].toLowerCase()];
    }


    if(!messageArr.hasOwnProperty(e.message.args[0].toLowerCase())) {
        messageArr[e.message.args[0].toLowerCase()] = [];
    }

    messageArr[e.message.args[0].toLowerCase()].push({text: e.message.args[1]});

    $('body , .message-box').fadeIn(200);
    $('.select-box , .send-box , .message-input').hide()
    var parts = e.message.args[0].split(" | ")
    var staff = e.message.args[0].split(" - ");

    color = args[e.message.args[0].toLowerCase()];

    if (staff[0] == "STAFFCHAT") {
        color = args['staff'];
        parts[0] = "STAFF";
        parts[1] = staff[1];
    }


    var textObject = e.message.args[1]; 
    if (setData === false) {
    $('.message-box').append(`
    <div class="message">
    <div class="item" style="border-left: 0.15vw solid ${color}">
      <div class="type">FEED</div>
      <div class="header">${parts[0]}</div>
      <div class="text">${textObject}</div>
    </div>
    </div>  
    `);
    }

    $.post('https://hpx-chat/load', JSON.stringify({}));
    setTimeout(function(){
        if (menuOpen === false) {
            $('body').fadeOut(200);
        }                
    },timeOut)
        
}

function newSuggestion(e) {
    if (e.suggestion === undefined) {
        return;
    }

    $.each(e, function (i, v) { 
        if (v.name === undefined) {
            return;
        }

        if (v.help === undefined || v.help.trim() === '') {
            return;
        }

        if (v.params === undefined || v.params.length === 0) {
            return;
        }

        var existingSuggestion = $('.suggestion-box').find('.suggestion-item').filter(function() {
            return $(this).find('.command').text().trim() === v.name;
        });

        if (existingSuggestion.length > 0) {
            existingSuggestion.find('.desc').text(v.help);
        } else {
            var helpText = JSON.stringify(v.params[0].help).replace(/^"(.*)"$/, '$1');
            $('.suggestion-box').append(`
                <div class="suggestion-item">
                    <div class="command"> <span style="color:rgb(61, 212, 162);text-shadow: 0 0 0.2vw rgb(12 181 142)"> ${v.name} </span> <span style="margin-left:0.5%">  ${helpText}  </span> </div>
                    <div class="desc">${v.help}</div>
                </div>
            `);
        }
    });
}



function addSuggestions(e) {
    if (e.suggestion === undefined) {
        return;
    }

    $.each(e, function (i, v) { 
        if (v.name === undefined || v.help === undefined || v.help.trim() === '' || v.name.trim() === '' ){
            return;
        } else {
            if (Array.isArray(v.params) && v.params.length > 0 && v.params[0].hasOwnProperty('help')) {
                var helpText = JSON.stringify(v.params[0].help).replace(/^"(.*)"$/, '$1');
                $('.suggestion-box').append(`
                    <div class="suggestion-item">
                    <div class="command"><span style="color:rgb(61, 212, 162);text-shadow: 0 0 0.2vw rgb(12 181 142)"> ${v.name} </span> <span style="margin-left:0.5%">  ${helpText} </span></div>
                    <div class="desc">${v.help}</div>
                    </div>
                `);
            }
        }
    });
    

}


function open(e){
    userInfo = e.userInfo;
    timeOut = e.timeOut;
    if (menuOpen === false) {
        menuOpen = true;
        $('body , .message-box , .send-box , .select-box , .message-input').fadeIn(200);  
    }
    $.post('https://hpx-chat/load', JSON.stringify({}));
}


function state(e){
    timeOut = e.timeOut;
    if (e.mask) {
        userInfo.name = "ANONYMOUS";        
    }

    if (e.state) {
        $('body').hide();
    }
}


function sendMessage() { 
    let text = $(".message-input").val();
    let command = $(".select-item.active").text();

    if (text === undefined || text === "") {
        return;
    }

    var words = text.split(" ");
    var firstWord = words.shift().toLowerCase();

    if (firstWord.startsWith("/")) {
        firstWord = firstWord.substring(1);
    }

    if (!messageArr.hasOwnProperty(firstWord)) {
        messageArr[firstWord] = []; 
    }


     messageArr[firstWord].push({text: text});

    if (firstWord=="clear") {
        $(".message-box").empty();
        $(".message-input").val('');
        $('body').hide();
        menuOpen = false;
        $.post('https://hpx-chat/close', JSON.stringify({}));
        return;
    }

    setData = true;
    $('.message-box').append(`
    <div class="message">
    <div class="item" style="border-left: 0.15vw solid ${color}">
      <div class="type" >${command.toUpperCase()}</div>
        <div class="header">${userInfo.name} [${userInfo.id}] </div>
        <div class="text">${text}</div>
        </div>
    </div>
    `);


    $('.message-input , .select-box , .send-box , .suggestion-box').hide();
    menuOpen = false;
    $.post('https://hpx-chat/send', JSON.stringify({text: text, command: command}));
    $(".message-input").val('');
    var messageBox = $('.message-box');
    messageBox.scrollTop(messageBox[0].scrollHeight);
    // setTimeout(function(){
    //     if (menuOpen === false) {
    //         $('body').fadeOut(200);
    //     }                
    // },timeOut)

}



$(document).on('click', '.send-box', function (e) {
    sendMessage()
});

$(document).on('click', '.select-box .select-item', function (e) {
    $(this).closest('.select-box').find('.select-item').removeClass('active');
    $(this).addClass('active');

    let command = $(this).text().toLowerCase();

    $(".message-box").empty();
    if (command === "feed") {
        $.each(messageArr, function (key, value) { 
            $.each(value, function (indexInArray, valueOfElement) { 
            $('.message-box').append(`
                <div class="message">
                <div class="item" style="border-left: 0.15vw solid ${args[command]}">
                  <div class="type" >${command.toUpperCase()}</div>
                    <div class="header">${userInfo.name} [${userInfo.id}]</div>
                    <div class="text">${valueOfElement.text}</div>
                    </div>
                </div>
            `);
            });
        });
    } else if (messageArr.hasOwnProperty(command)) {
        $.each(messageArr[command], function (indexInArray, valueOfElement) { 
            $('.message-box').append(`
            <div class="message">
            <div class="item" style="border-left: 0.15vw solid ${args[command]}">
              <div class="type" >${command.toUpperCase()}</div>
                <div class="header">${userInfo.name} [${userInfo.id}]</div>
                <div class="text">${valueOfElement.text}</div>
                </div>
            </div>
            `);
        });
    }
});



$(".message-input").on('input', function () {
    let searchValue = $(".message-input").val().toLowerCase(); 
    if (searchValue.length > 0) {
        $(".suggestion-box").css('display', 'flex');
    }else{
        $(".suggestion-box").hide();
    }

    $(".command").each(function () {
      let memName = $(this).text().toLowerCase(); 
      if (memName.includes(searchValue)) {
        $(this).parent().show(); 
      } else {
        $(this).parent().hide(); 
        }
    })
});

var cIndex = -1;

$(".message-input").keydown(function(e) {

    if (e.keyCode==38) {
        e.preventDefault();
        if (cIndex <= Object.keys(messageArr).length) {
            cIndex++;
            if (cIndex === Object.keys(messageArr).length) {
                cIndex = -1;
                $(".message-input").val('');
                return;
            }
            var message = Object.keys(messageArr)[cIndex];
            var text = messageArr[message][0].text;    
            $(".message-input").val(text);

        }else{
            $(".message-input").val('');
        }
    }

    if (e.keyCode==40) {
        e.preventDefault();
        if (cIndex > 0) {
            cIndex--;
            var message = Object.keys(messageArr)[cIndex];
            var text = messageArr[message][0].text;       
            $(".message-input").val(text);
        }else{
            $(".message-input").val('');
        }
    }

});


$(".message-input").keypress(function(e) {
    if (e.keyCode === 13) {
        sendMessage()
    }
});


var currentIndex = 2;
$(document).ready(function() {
    $(document).on('keydown', function (e) {
        $('.message-input').focus();
        
        if (e.keyCode === 9) {
          $('.select-item').removeClass('active');
        e.preventDefault(); 
        $(`.${currentIndex}`).addClass('active');
        if (currentIndex === 6) {
            currentIndex = 1;
        }
        $(this).removeClass('active');
      }

      if (e.keyCode == 27) {
        $('body').fadeOut(200);
        menuOpen = false;
        $.post('https://hpx-chat/close', JSON.stringify({}));
      }

    });
  });
  