Config = {
    ServerCallbacks = {}, -- Don't edit or change
    timeOut = 5000, -- Time in milliseconds before the message disappears
    perms = {'superadmin', 'admin', 'mod'},
    mask = true, --if true, the character's name will be ANONYMOUS when wearing a mask
    startMarker = "/" --If you leave it blank, you don't need to write any signs at the beginning of the commands
}