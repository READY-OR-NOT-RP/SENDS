function SetPlayerSkin(ped, skin)
    if Utils.SkinScript == "illenium-appearance" then
        exports['illenium-appearance']:setPedAppearance(ped, skin)
    elseif Utils.SkinScript == "fivem-appearance" then
        exports['fivem-appearance']:setPedAppearance(ped, skin)
    elseif Utils.SkinScript == "skinchanger" or Utils.SkinScript == "esx_skin" then
        TriggerEvent("skinchanger:applySkin", skin, nil, ped)
    elseif Utils.SkinScript == "qb-clothing" then
        TriggerEvent('qb-clothing:client:loadPlayerClothing', skin, ped)
	elseif Utils.SkinScript == "rcore_clothing" then
		exports['rcore_clothing']:setPedSkin(ped, skin)
    end
end

function SkinMenu(skin)
	local playerPed = PlayerPedId()

	if Utils.SkinScript == 'skinchanger' then
		TriggerEvent('esx_skin:openSaveableMenu', function()
			SetPedAoBlobRendering(playerPed, true)
			ResetEntityAlpha(playerPed)
			SetEntityVisible(playerPed,true)
		end)
	elseif Utils.SkinScript == 'fivem-appearance' then
		SetPedAoBlobRendering(playerPed, true)
		ResetEntityAlpha(playerPed)
		SetEntityVisible(playerPed, true)

		exports['fivem-appearance']:startPlayerCustomization(function(appearance)
			if appearance then
				TriggerServerEvent("fivem-appearance:save", appearance)
			end
		end, {
			components = true, componentConfig = { masks = true, upperBody = true, lowerBody = true, bags = true, shoes = true, scarfAndChains = true, bodyArmor = true, shirts = true, decals = true, jackets = true },
			props = true, propConfig = { hats = true, glasses = true, ear = true, watches = true, bracelets = true },
			enableExit = true,
		})
	elseif Utils.SkinScript == 'illenium-appearance' then
		SetPedAoBlobRendering(playerPed, true)
		ResetEntityAlpha(playerPed)
		SetEntityVisible(playerPed,true)

		exports['illenium-appearance']:startPlayerCustomization(function(appearance)
			if appearance then
				TriggerServerEvent("illenium-appearance:server:saveAppearance", appearance)
			end
		end, {
			components = true, componentConfig = { masks = true, upperBody = true, lowerBody = true, bags = true, shoes = true, scarfAndChains = true, bodyArmor = true, shirts = true, decals = true, jackets = true },
			props = true, propConfig = { hats = true, glasses = true, ear = true, watches = true, bracelets = true },
			enableExit = true,
		})
	elseif Utils.SkinScript == 'qb-clothing' then
		if Config.SkinMenu[Utils.SkinScript].event then
			TriggerEvent(Config.SkinMenu[Utils.SkinScript].event)
		elseif Config.SkinMenu[Utils.SkinScript].exports then
			Config.SkinMenu[Utils.SkinScript].exports()
		end
	elseif Utils.SkinScript == 'rcore_clothing' then
		TriggerEvent('rcore_clothing:openCharCreator')
	end
end

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(playerData, isNew, skin)
	if Utils.Framework ~= "es_extended" then return end

    Thread = false

    DestroyCam(camera, false)
    RenderScriptCams(false, false, 0, false, false)
    SetNuiFocus(0, 0)

    if #peds > 0 then
		for k, v in pairs(peds) do
			DeleteEntity(v)
		end
	end

	local ped = PlayerPedId()
	local spawn = playerData?.coords or Config.DefaultSpawn
    SetEntityVisible(ped, true)
    FreezeEntityPosition(ped, false)

	DoScreenFadeOut(100)

	SetEntityCoordsNoOffset(ped, spawn.x, spawn.y, spawn.z, false, false, false, true)
	SetEntityHeading(ped, spawn.heading)

	local size = 0

	if skin then
		for _, _ in pairs(skin) do
			size = size + 1
		end
	end

	if isNew or not skin or size <= 1 then
		local finished = false

		skin = Config.Default[playerData.sex]
		skin.sex = playerData.sex == "m" and 0 or 1
		local model = skin.sex == 0 and GetHashKey("mp_m_freemode_01") or GetHashKey("mp_f_freemode_01")

		RequestModel(model)

		while not HasModelLoaded(model) do
			RequestModel(model)
			Wait(0)
		end

		SetPlayerModel(PlayerId(), model)
		SetModelAsNoLongerNeeded(model)

		if Utils.SkinScript == "skinchanger" then
			TriggerEvent('skinchanger:loadSkin', skin, function()
				ped = PlayerPedId()

				DisableAllControlActions(0)
				MumbleSetVolumeOverride(PlayerId(), 0.0)
				SetPlayerInvincible(PlayerId(), 1)

				ResetEntityAlpha(ped)
				SetPedAoBlobRendering(ped, 1)
				SetEntityHeading(ped, spawn.heading)
				FreezeEntityPosition(ped, 1)

				TriggerEvent('esx_skin:openSaveableMenu', function()
					finished = true
				end, function()
					finished = true
				end)
			end)

			repeat
				ThefeedHideThisFrame()
				HideHudComponentThisFrame(11)
				HideHudComponentThisFrame(12)
				HideHudComponentThisFrame(21)
				HideHudAndRadarThisFrame()

				Wait(0)
			until finished
		end

		FreezeEntityPosition(PlayerPedId(), 0)
		SetPlayerInvincible(PlayerId(), 0)
		EnableAllControlActions(0)
	else
		TriggerEvent('skinchanger:loadSkin', skin)
	end

	DoScreenFadeIn(400)

    repeat
        Wait(200)
    until not IsScreenFadedOut()

    TriggerServerEvent("esx:onPlayerSpawn")
    TriggerEvent("esx:onPlayerSpawn")
    TriggerEvent("playerSpawned")
    TriggerEvent("esx:restoreLoadout")
    TriggerEvent("esx:restoreLoadout")
	TriggerEvent('rcore_clothing:openCharCreator')
end)