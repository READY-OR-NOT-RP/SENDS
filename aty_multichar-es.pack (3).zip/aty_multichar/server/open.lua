function SpawnSelector(src, playerData, firtSpawn)
    TriggerClientEvent("aty_spawnselector:client:open", src, firtSpawn, playerData)
    -- TriggerClientEvent('apartments:client:setupSpawnUI', src, cData)
end

function GiveStarterItems(src)
    for k, v in pairs(Config.StarterItems) do
        AddItem(src, k, v)
    end
end

RegisterCommand("purchase_slot", function(src, args)
    if src ~= 0 then
        return
    end

    local transaction = args[1]
    local slots = args[2]

    ExecuteSql("INSERT INTO multichar_purchases (transaction, slots) VALUES (@transaction, @slots)", {
        ["@transaction"] = transaction,
        ["@slots"] = slots
    })
end)

---@param id string|number The players identifier or server id
function GetPlayerSkinData(id)
    id = type(id) == "number" and GetIdentifier(id) or id

    if Utils.SkinScript == "qb-clothing" then
        local result = ExecuteSql('SELECT * FROM playerskins WHERE citizenid = @citizenid', {
            ['@citizenid'] = id,
        })
        if result[1] ~= nil then
            return json.decode(result[1].skin)
        else
            return nil
        end
    elseif Utils.SkinScript == "skinchanger" then
        local result = ExecuteSql('SELECT skin FROM users WHERE identifier = @identifier', {
            ['@identifier'] = id
        })
        if result[1] ~= nil then
            return json.decode(result[1].skin)
        else
            return nil
        end
    elseif Utils.SkinScript == "fivem-appearance" then
        if Utils.Framework == "es_extended" then
            local result = ExecuteSql('SELECT skin FROM users WHERE identifier = @identifier', {
                ['@identifier'] = id
            })
            if result[1] ~= nil then
                return json.decode(result[1].skin)
            else
                return nil
            end
        elseif Utils.Framework == "qb-core" then
            local result = ExecuteSql('SELECT skin FROM playerskins WHERE citizenid = @citizenid', {
                ['@citizenid'] = id
            })
            if result[1] ~= nil then
                return json.decode(result[1].skin)
            else
                return nil
            end
        end
    elseif Utils.SkinScript == "illenium-appearance" then
        if Utils.Framework == "es_extended" then
            local result = ExecuteSql('SELECT skin FROM users WHERE identifier = @identifier', {
                ['@identifier'] = id
            })
            if result[1] ~= nil then
                return json.decode(result[1].skin)
            else
                return nil
            end
        elseif Utils.Framework == "qb-core" then
            local result = ExecuteSql('SELECT skin FROM playerskins WHERE citizenid = @citizenid', {
                ['@citizenid'] = id
            })
            if result[1] ~= nil then
                return json.decode(result[1].skin)
            else
                return nil
            end
        end
    elseif Utils.SkinScript == "esx_skin" then
        local result = ExecuteSql('SELECT skin FROM users WHERE identifier = @identifier', {
            ['@identifier'] = id
        })
        if result[1] ~= nil then
            return json.decode(result[1].skin)
        else
            return nil
        end
    elseif Utils.SkinScript == "rcore_clothing" then
        local skin = exports["rcore_clothing"]:getSkinByIdentifier(identifier) 

        if skin then
            return skin
        else
            return nil
        end
    end
end