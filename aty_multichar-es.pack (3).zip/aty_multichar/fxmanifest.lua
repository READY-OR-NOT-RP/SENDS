fx_version 'cerulean'
game 'gta5'
author 'atiysu'
lua54 'yes'

games {
  "gta5",
  "rdr3"
}

ui_page 'ui/index.html'

shared_scripts{
  "shared/locale.lua",
  "shared/*.lua",
}

client_scripts {
  "client/utils.lua",
  "client/*.lua",
}
server_script {
  "server/utils.lua",
  "server/*.lua",
  "@mysql-async/lib/MySQL.lua",
}

files {
	'ui/index.html',
	'ui/**/*',
}

local isEscrowed = true
if isEscrowed then
  escrow_ignore {
    "shared/*.lua",
    "client/open.lua",
    "server/open.lua",
  }
else
  escrow_ignore {
    "shared/*.lua",
    "client/**/*",
    "server/**/*",
  }
end
dependency '/assetpacks'