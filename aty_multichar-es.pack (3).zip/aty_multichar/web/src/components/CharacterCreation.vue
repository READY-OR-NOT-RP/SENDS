<script setup>
function setButtonActive(e) {
  const buttons = document.querySelectorAll('.btn')
  buttons.forEach((btn) => btn.classList.remove('active'))
  e.target.classList.add('active')
}

import { useMenuData } from '@/stores/data'
import { fetchNui } from '@/utils'
const menuData = useMenuData()

async function createCharacter() {
  let firstname = document.getElementById('firstname').value
  let lastname = document.getElementById('lastname').value
  let nationality = document.getElementById('nation').value
  let birthdate = document.getElementById('birthdate').value
  let gender = document.querySelector('.btn.active').id

  if (firstname && lastname && nationality && birthdate && gender) {
    let resp = await fetchNui('createCharacter', {
      firstname: firstname,
      lastname: lastname,
      nationality: nationality,
      birthdate: birthdate,
      gender: gender
    })

    if (resp) {
      menuData.toggleMenu(false)
    }
  }
}
</script>

<template>
  <Transition name="opacity">
    <div class="character-creation">
      <div class="creation-box">
        <div class="header-wrapper">
          <div class="icon"><img src="@/assets/register-icon.png" /></div>
          <div class="title-wrapper">
            <div class="title">Welcome to</div>
            <div class="subtitle">Registraion</div>
          </div>

          <div class="close-btn-wrapper" @click="menuData.setMenu('info')">
            <div class="icon-wrapper">
              <svg
                width="12"
                height="12"
                viewBox="0 0 12 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  d="M3.25509 0.0171517C2.47812 0.124598 1.75529 0.665158 1.42094 1.38885C1.23406 1.79327 1.21042 1.96413 1.21019 2.91092C1.20997 3.83458 1.21031 3.83659 1.38903 4.02491C1.49614 4.13771 1.73004 4.21438 1.88231 4.18654C2.05235 4.15546 2.21661 4.04186 2.3023 3.89605L2.38064 3.76282L2.39553 2.93067C2.40862 2.19888 2.41686 2.0832 2.46382 1.97158C2.6291 1.5788 2.96847 1.29302 3.36818 1.20992C3.46256 1.19032 4.56782 1.18309 6.69674 1.1882L9.88402 1.19585L10.0392 1.25912C10.3522 1.38676 10.624 1.65858 10.7516 1.97158L10.8149 2.12673V6.0054V9.88407L10.7516 10.0392C10.624 10.3522 10.3522 10.624 10.0392 10.7517L9.88402 10.815L6.69674 10.8226C4.56782 10.8277 3.46256 10.8205 3.36818 10.8009C2.96847 10.7178 2.6291 10.432 2.46382 10.0392C2.41686 9.9276 2.40862 9.81191 2.39553 9.08013L2.38064 8.24798L2.3023 8.11475C2.21661 7.96894 2.05235 7.85534 1.88231 7.82426C1.73004 7.79641 1.49614 7.87309 1.38903 7.98589C1.21031 8.17421 1.20997 8.17622 1.21019 9.09987C1.21036 9.84196 1.21699 9.96799 1.26664 10.1751C1.47332 11.0373 2.12163 11.6944 3.01538 11.9478C3.18883 11.9969 3.38132 11.9997 6.59776 11.9997C10.4537 11.9997 10.1404 12.0182 10.6738 11.7594C11.1742 11.5166 11.5187 11.1723 11.7597 10.6739C12.0199 10.1359 11.9996 10.531 11.9996 6.0054C11.9996 1.47976 12.0199 1.87485 11.7597 1.33689C11.5188 0.838669 11.1772 0.497204 10.67 0.247503C10.1364 -0.0152599 10.3417 -0.00284824 6.59776 0.0015805C4.80584 0.00369614 3.30163 0.0106919 3.25509 0.0171517ZM5.13979 3.67633C4.94454 3.76725 4.84234 3.91938 4.82615 4.14318C4.80601 4.42143 4.84093 4.47935 5.32363 4.96874L5.76187 5.41302L3.11216 5.41364C0.593253 5.41423 0.456923 5.41683 0.349648 5.4665C-0.116549 5.68233 -0.116549 6.32847 0.349648 6.54429C0.456923 6.59397 0.593253 6.59657 3.11216 6.59716L5.76187 6.59778L5.32363 7.04206C4.83994 7.53241 4.80598 7.58897 4.82634 7.87029C4.84801 8.17009 5.05678 8.37122 5.3735 8.39748C5.48557 8.40676 5.55248 8.39525 5.64401 8.35094C5.72717 8.31071 6.07915 7.97718 6.75643 7.29684C7.71509 6.33389 7.74835 6.29682 7.78149 6.15474C7.81892 5.99429 7.80332 5.87575 7.72471 5.72331C7.6475 5.57358 5.76009 3.70432 5.63253 3.65128C5.48213 3.58875 5.30901 3.59755 5.13979 3.67633Z"
                  fill="white"
                />
              </svg>
            </div>
            <span>Exit</span>
          </div>
        </div>

        <div class="inputs-wrapper">
          <div class="input-box">
            <img src="@/assets/input-outer.png" alt="" class="outer" />
            <div class="input-title">Firstname</div>
            <div class="input-wrapper">
              <div class="input-icon"><img src="@/assets/name-icon.png" /></div>
              <input type="text" placeholder="John" id="firstname" />
            </div>
          </div>
          <div class="input-box">
            <img src="@/assets/input-outer.png" alt="" class="outer" />
            <div class="input-title">Lastname</div>
            <div class="input-wrapper">
              <div class="input-icon"><img src="@/assets/name-icon.png" /></div>
              <input type="text" placeholder="Doe" id="lastname" />
            </div>
          </div>
          <div class="input-box">
            <img src="@/assets/input-outer.png" alt="" class="outer" />
            <div class="input-title">Nationality</div>
            <div class="input-wrapper">
              <div class="input-icon"><img src="@/assets/nation-icon.png" /></div>
              <input type="text" placeholder="America" id="nation" />
            </div>
          </div>
          <div class="input-box">
            <img src="@/assets/input-outer.png" alt="" class="outer" />
            <div class="input-title">Birthdate</div>
            <div class="input-wrapper">
              <div class="input-icon"><img src="@/assets/birth-icon.png" /></div>
              <input type="date" id="birthdate" />
            </div>
          </div>
          <div class="input-box">
            <img src="@/assets/input-outer.png" alt="" class="outer" />
            <div class="input-title">Gender</div>
            <div class="button-wrapper">
              <button class="btn active" @click="setButtonActive" id="male">Male</button>
              <button class="btn" @click="setButtonActive" id="female">Female</button>
            </div>
          </div>
        </div>

        <div class="create-btn-wrapper">
          <div class="btn-wrapper" @click="createCharacter()">
            <div class="btn">Complete Registration</div>
          </div>
        </div>
      </div>
    </div>
  </Transition>
</template>

<style scoped>
.character-creation {
  width: 100vw;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0 4vw;
  background: radial-gradient(
    50% 50% at 50% 50%,
    rgba(33, 43, 56, 0.74) 0%,
    rgba(13, 21, 31, 0.83) 100%
  );
}

.creation-box::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 20%;
  width: 13vw;
  height: 13vw;
  background: rgba(114, 110, 255, 0.45);
  opacity: 0.55;
  filter: blur(112px);
  border-radius: 50%;
  z-index: -1;
}

.creation-box::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 60%;
  width: 16vw;
  height: 16vw;
  background: rgba(90, 255, 231, 0.45);
  opacity: 0.4;
  filter: blur(112px);
  border-radius: 50%;
  z-index: -1;
}

.creation-box {
  background: radial-gradient(53.37% 84.43% at 50% 50%, #212b38 0%, rgba(33, 43, 56, 0.88) 100%);
  border: 1px solid rgba(90, 255, 231, 0.1);
  border-radius: 31px;
  width: 30vw;
  height: fit-content;
  padding: 4vh;
  display: flex;
  flex-direction: column;
  gap: 3vh;
  overflow: hidden;
  position: relative;
  z-index: 1;
}

.header-wrapper {
  display: flex;
  align-items: center;
  height: 7vh;
  gap: 2vh;
  position: relative;
}

.icon {
  width: 7vh;
  height: 7vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

.icon img {
  width: 100%;
  height: 100%;
}

.title-wrapper {
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-top: 3%;
}

.title {
  font-weight: 275;
  font-size: 24px;
  line-height: 100%;
  color: #5affe7;
  text-shadow: 0px 0px 68px #5affe7;
}

.subtitle {
  font-family: 'Brothership';
  font-size: 48px;
  color: #5affe7;
  text-shadow: 0px 0px 68px #5affe7;
}

.close-btn-wrapper {
  position: absolute;
  right: 0;
  top: 0;
  display: flex;
  align-items: center;
  gap: 1vh;
  cursor: pointer;
  background: rgba(255, 90, 90, 0.42);
  box-shadow: 0px 4px 33px rgba(255, 90, 90, 0.35);
  border-radius: 2px;
  padding: 3px 7px 3px 3px;
  font-weight: 300;
  font-size: 12px;
  line-height: 100%;
  color: #ffffff;
}

.icon-wrapper {
  width: 2vh;
  height: 2vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: rgba(255, 90, 90, 0.42);
  box-shadow: 0px 4px 33px rgba(255, 90, 90, 0.35);
  border-radius: 2px;
}

.close-btn-wrapper:hover {
  background: rgba(255, 90, 90, 0.52);
}

/*  Input Box  */
.inputs-wrapper {
  display: flex;
  flex-direction: column;
  gap: 1.5vh;
  z-index: 1;
}

.outer {
  width: 100%;
  height: 100%;
  position: absolute;
  z-index: -1;
}

.input-title {
  padding: 1.5vh;
  font-size: 13px;
  line-height: 100%;
  color: #ffffff;
}

.input-wrapper {
  display: flex;
  align-items: center;
  gap: 1vh;
  padding: 1vh;
  background: radial-gradient(
    56.82% 187.56% at 50% 50%,
    rgba(255, 255, 255, 0.08) 0%,
    rgba(255, 255, 255, 0) 100%
  );
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 7px;
}

.input-box {
  position: relative;
}

.input-icon {
  width: 3.5vh;
  height: 3.5vh;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: 0px 4px 41px rgba(104, 174, 245, 0.3);
  border-radius: 5px;
}

.input-icon img {
  width: 100%;
  height: 100%;
}

input {
  width: calc(100% - 5vh);
  height: 100%;
  background: none;
  border: none;
  color: #ffffff;
  font-size: 14px;
  font-weight: 300;
  outline: none;
}

input[type='date']::-webkit-calendar-picker-indicator {
  color: rgba(0, 0, 0, 0);
  opacity: 1;
  display: block;
  background: url('@/assets/date-icon.png') no-repeat;
  background-size: cover;
  width: 2vh;
  height: 2vh;
}

.button-wrapper {
  display: flex;
  gap: 1vh;
}

.input-box .btn {
  width: 100%;
  height: 6vh;
  background: radial-gradient(
    55.17% 167.56% at 50% 50%,
    rgba(255, 255, 255, 0.08) 0%,
    rgba(255, 255, 255, 0) 100%
  );
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 7px;
  font-size: 14px;
  font-weight: 300;
  cursor: pointer;
  font-size: 14px;
  line-height: 100%;
  color: #ffffff;
  position: relative;
}

.input-box .btn::after {
  content: '';
  position: absolute;
  left: 1vh;
  top: 50%;
  transform: translateY(-50%);
  width: 2px;
  height: 50%;
  background: #5affe7;
  box-shadow: 0px 0px 8px rgba(90, 255, 231, 0.55);
  border-radius: 1px;
}

.input-box .btn:last-child::after {
  background: #e478ff;
  box-shadow: 0px 0px 8px rgba(228, 120, 255, 0.55);
}

.input-box .btn:hover {
  background: radial-gradient(
      127.42% 546.41% at 50% 50%,
      rgba(255, 255, 255, 0.08) 0%,
      rgba(255, 255, 255, 0) 100%
    )
    /* warning: gradient uses a rotation that is not supported by CSS and may not behave as expected */;
}

.input-box .btn.active {
  background: linear-gradient(
    97.12deg,
    rgba(90, 255, 231, 0.25) -14.73%,
    rgba(99, 96, 208, 0.25) 116.65%
  );
  border: 1px solid rgba(90, 255, 231, 0.2);
  box-shadow: 0px 4px 41px rgba(104, 174, 245, 0.15);
}

/*  Create Button  */
.create-btn-wrapper {
  display: flex;
  justify-content: space-between;
  gap: 1vh;
}

.create-btn-wrapper .btn-wrapper {
  height: 5vh;
  background: rgba(0, 0, 0, 0.2);
  border-radius: 5px;
  font-size: 14px;
  font-weight: 300;
  cursor: pointer;
  font-size: 13px;
  line-height: 100%;
  color: #ffffff;
  padding: 0.7vh;
}

.create-btn-wrapper .btn-wrapper:first-child {
  width: 100%;
}

.create-btn-wrapper .btn-wrapper:hover {
  background: rgba(0, 0, 0, 0.3);
}

.create-btn-wrapper .btn-wrapper .btn {
  background: linear-gradient(97.12deg, #5affe7 -14.73%, #6360d0 116.65%);
  box-shadow: 0px 4px 41px rgba(104, 174, 245, 0.25);
  border-radius: 2px;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.create-btn-wrapper .btn-wrapper img {
  width: 100%;
  height: 100%;
}

/*  Anim  */
.opacity-enter-active,
.opacity-leave-active {
  transition: opacity 0.3s ease;
}

.opacity-enter-from,
.opacity-leave-to {
  opacity: 0;
}
</style>
