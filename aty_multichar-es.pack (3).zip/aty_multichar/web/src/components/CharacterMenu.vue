<script setup>
import CharacterSlots from './CharacterSlots.vue'
import CharacterInformation from './CharacterInformation.vue'
import CodePop from './CodePop.vue'
</script>

<template>
  <div class="character-menu">
    <TransitionGroup name="slide">
      <CharacterSlots />
      <CharacterInformation />
      <CodePop />
    </TransitionGroup>
  </div>
</template>

<style scoped>
.character-menu {
  width: 100vw;
  height: 100vh;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 4vw;
  background: linear-gradient(
    90deg,
    #0d151f 0%,
    rgba(13, 21, 31, 0.75) 20%,
    rgba(13, 21, 31, 0) 50%,
    rgba(13, 21, 31, 0.75) 80%,
    #0d151f 100%
  );
}

.slide-move, /* apply transition to moving elements */
.slide-enter-active,
.slide-leave-active {
  transition: all 0.3s ease;
}

.slide-enter-from,
.slide-leave-to {
  opacity: 0;
  transform: translateX(30px);
}
</style>
