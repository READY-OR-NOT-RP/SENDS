<script setup>
import { useMenuData } from '@/stores/data'
import { storeToRefs } from 'pinia'
import { formatMoney } from '@/utils'

const menuData = useMenuData()
const { selectedCharacter } = storeToRefs(menuData)
</script>

<template>
  <div class="char-info" v-if="selectedCharacter?.firstname">
    <div class="header-wrapper">
      <div class="title-wrapper">
        <div class="subtitle">Information About</div>
        <div class="title">Character</div>
      </div>
    </div>

    <div class="character-info-wrapper">
      <div class="row">
        <div class="box">
          <img src="@/assets/birth-bg.png" class="bg" />
          <div class="title">Birthdate</div>
          <div class="data">{{ selectedCharacter.birthdate }}</div>
        </div>
      </div>
      <div class="row">
        <div class="column">
          <div class="box">
            <img src="@/assets/gender-bg.png" class="bg" />
            <div class="title">Gender</div>
            <div class="data">{{ selectedCharacter.gender }}</div>
          </div>
          <div class="box">
            <img src="@/assets/job-bg.png" class="bg" />
            <div class="title">Job</div>
            <div class="data">{{ selectedCharacter.job }}</div>
          </div>
        </div>
        <div class="column">
          <div class="box full">
            <img src="@/assets/location-bg.png" class="bg" />
            <div class="title">Last Location</div>
            <div class="data">{{ selectedCharacter.position }}</div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="box">
          <img src="@/assets/cash-bg.png" class="bg" />
          <div class="title">Cash</div>
          <div class="data">{{ formatMoney(selectedCharacter.cash) }}</div>
        </div>
      </div>
      <div class="row">
        <div class="box">
          <img src="@/assets/bank-bg.png" class="bg" />
          <div class="title">Bank</div>
          <div class="data">{{ formatMoney(selectedCharacter.bank) }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.char-info {
  width: 20vw;
  height: fit-content;
  display: flex;
  flex-direction: column;
  gap: 3vh;
}
.char-info .header-wrapper {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  height: 6vh;
  width: 100%;
}

.char-info .title-wrapper {
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: right;
}

.char-info .title-wrapper .subtitle {
  font-weight: 275;
  font-size: 24px;
  line-height: 100%;
  color: #5affe7;
  text-shadow: 0px 0px 68px #5affe7;
}

.char-info .title-wrapper .title {
  font-family: 'Brothership';
  font-weight: 400;
  font-size: 48px;
  line-height: 100%;
  color: #5affe7;
  text-shadow: 0px 0px 68px #5affe7;
}

.character-info-wrapper {
  display: flex;
  flex-direction: column;
  gap: 1vh;
  width: 100%;
  height: fit-content;
}

.row {
  width: 100%;
  display: flex;
  gap: 1vh;
}

.column {
  display: flex;
  flex-direction: column;
  gap: 1vh;
  width: 50%;
}

.box {
  height: 10vh;
  width: 100%;
  background: radial-gradient(
    143.08% 82.07% at 50% 50%,
    rgba(255, 255, 255, 0.0765) 0%,
    rgba(255, 255, 255, 0) 100%
  );
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 7px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  position: relative;
  overflow: hidden;
  padding-left: 4vh;
  z-index: 2;
}

.box:not(.full):after {
  content: '';
  position: absolute;
  left: 2vh;
  top: 50%;
  transform: translateY(-50%);
  width: 2px;
  height: 35%;
  background: #5affe7;
  box-shadow: 0px 0px 68px #5affe7;
}

.box.full {
  height: 21vh;
}

.box.full:after {
  content: '';
  position: absolute;
  top: 2vh;
  left: 50%;
  transform: translateX(-50%);
  height: 2px;
  width: 35%;
  background: #5affe7;
  box-shadow: 0px 0px 68px #5affe7;
}

.box:not(.full) img {
  position: absolute;
  right: 0;
  top: 0;
  height: 100%;
  z-index: -1;
}

.box.full {
  display: flex;
  justify-content: start;
  align-items: center;
  padding: 0;
  padding-top: 4vh;
}

.box.full img {
  position: absolute;
  right: 0;
  bottom: 0;
  width: 100%;
  z-index: -1;
}

.title {
  font-weight: 300;
  font-size: 12px;
  line-height: 100%;
  color: rgba(255, 255, 255, 0.55);
}

.data {
  font-size: 14px;
  line-height: 100%;
  color: #fff;
}
</style>
