<script setup>
import { useMenuData } from '@/stores/data'
import { fetchNui } from '@/utils'
import { storeToRefs } from 'pinia'

const menuData = useMenuData()
const { slotsPrice, selectedCharacterIndex } = storeToRefs(menuData)

defineProps({
  character: {
    type: Object,
    required: true
  },
  slot: {
    type: Number,
    required: true
  },
  isLocked: {
    type: Boolean,
    required: true
  }
})

function setSelectedCharacter(data, index, isLocked) {
  if (isLocked) return
  if (data?.firstname) menuData.setSelectedCharacter(data, index)
  else menuData.setMenu('creation')
}

async function useChar(character) {
  let resp = await fetchNui('selectCharacter', character)
  if (resp) menuData.toggleMenu(false)
}

function deleteCharacter(character) {
  fetchNui('deleteCharacter', character)
}
</script>

<template>
  <div class="slot">
    <div
      class="box"
      :class="selectedCharacterIndex === slot ? 'active' : ''"
      @click="setSelectedCharacter(character, slot, isLocked)"
    >
      <div class="profile-box">
        <img
          v-if="character?.firstname"
          :src="character?.image || '/path/to/default-image.jpg'"
          alt="Character Image"
        />
        <div v-else-if="isLocked" class="locked-box">
          <img src="@/assets/locked-icon.png" alt="Locked" />
        </div>
        <div v-else class="create-btn">
          <svg
            width="17"
            height="17"
            viewBox="0 0 17 17"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect x="7" width="3" height="17" fill="white" />
            <rect x="17" y="7" width="3" height="17" transform="rotate(90 17 7)" fill="white" />
          </svg>
        </div>
      </div>

      <div class="title-wrapper">
        <div class="subtitle">
          {{ character?.firstname ? 'Name' : isLocked ? 'Purchase' : 'Click To Create' }}
        </div>
        <div class="title">
          {{
            character?.firstname
              ? `${character.firstname} ${character.lastname}`
              : isLocked
                ? 'Locked Slot'
                : 'Empty Slot'
          }}
        </div>
      </div>

      <div class="button-wrapper" v-if="character?.firstname">
        <div class="delete-btn btn" @click="deleteCharacter(character)">
          <img src="@/assets/delete-btn.png" alt="Delete" />
          <div class="icon">
            <svg width="19" height="23" viewBox="0 0 19 23" xmlns="http://www.w3.org/2000/svg">
              <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M6.82266 0.0473386C6.65636 0.088518 6.39662 0.26322 6.28659 0.407877C6.25695 0.446894 6.12377 0.701332 5.99064 0.973392L5.7486 1.46801L3.10294 1.46819C0.539861 1.46833 0.452833 1.47118 0.315253 1.5598C0.0230971 1.74784 0 1.84391 0 2.87133C0 3.89874 0.0230971 3.99481 0.315253 4.18286C0.455753 4.27331 0.553501 4.27433 9.5 4.27433C18.4465 4.27433 18.5442 4.27331 18.6847 4.18286C18.9769 3.99481 19 3.89874 19 2.87133C19 1.84391 18.9769 1.74784 18.6847 1.5598C18.5472 1.47118 18.4601 1.46833 15.8971 1.46819L13.2514 1.46801L13.0066 0.962718C12.7147 0.360256 12.493 0.121784 12.1535 0.0449001C11.8825 -0.016478 7.07158 -0.0142235 6.82266 0.0473386ZM1.35087 5.8045C1.35262 6.26506 2.27816 21.2816 2.31293 21.4136C2.51932 22.1967 3.21389 22.8352 3.98721 22.9528C4.40165 23.0157 14.5984 23.0157 15.0128 22.9528C15.7861 22.8352 16.4807 22.1967 16.6871 21.4136C16.7218 21.2816 17.6474 6.26506 17.6491 5.8045C17.6493 5.75867 15.9905 5.74698 9.5 5.74698C3.00946 5.74698 1.3507 5.75867 1.35087 5.8045Z"
                fill="#FF5A5A"
              />
            </svg>
          </div>
        </div>

        <div class="select-btn btn" @click="useChar(character)">
          <img src="@/assets/select-btn.png" alt="Select" />
          <div class="icon">
            <svg
              width="8"
              height="13"
              viewBox="0 0 8 13"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M1 1L7 6.5L1 12" stroke="#5AFFE7" />
            </svg>
          </div>
        </div>
      </div>

      <div class="locked-btn-wrapper" v-if="isLocked">
        <div class="price-box">
          <div class="title">Price</div>
          <div class="price">{{ slotsPrice }} Gold</div>
        </div>

        <div class="purchase-btn" @click="menuData.togglePopup(true)">
          <span>Purchase</span>
          <img src="@/assets/purchase-btn.png" alt="Purchase Button" />
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.slot {
  width: 100%;
  height: fit-content;
}

.box {
  width: 100%;
  height: fit-content;
  padding: 2vh;
  background: radial-gradient(
    143.08% 82.07% at 50% 50%,
    rgba(255, 255, 255, 0.0765) 0%,
    rgba(255, 255, 255, 0) 100%
  );
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 7px;
  display: flex;
  align-items: center;
  gap: 1vh;
  position: relative;
}

.box.active {
  background: radial-gradient(
    143.08% 82.07% at 50% 50%,
    rgba(255, 255, 255, 0.1275) 0%,
    rgba(255, 255, 255, 0) 100%
  );
}

.profile-box {
  width: 5vh;
  height: 5vh;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 5px;
  padding: 5px;
}

.profile-box img {
  width: 100%;
  height: 100%;
  border-radius: 3px;
}

.create-btn,
.locked-box {
  width: 100%;
  height: 100%;
  background: radial-gradient(
    143.08% 82.07% at 50% 50%,
    rgba(255, 255, 255, 0.1275) 0%,
    rgba(255, 255, 255, 0) 100%
  );
  border-radius: 3px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
}

.create-btn:hover {
  background: radial-gradient(
    143.08% 82.07% at 50% 50%,
    rgba(255, 255, 255, 0.2275) 0%,
    rgba(255, 255, 255, 0) 100%
  );
}

.locked-box img {
  height: 40%;
  width: auto;
}

.title-wrapper {
  display: flex;
  flex-direction: column;
}

.subtitle {
  font-weight: 300;
  font-size: 12px;
  line-height: 120%;
  color: rgba(255, 255, 255, 0.55);
}

.title {
  font-size: 16px;
  line-height: 120%;
  color: #ffffff;
}

.button-wrapper {
  position: absolute;
  right: 2vh;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  gap: 1vh;
  height: calc(100% - 4vh);
}

.select-btn,
.delete-btn {
  height: 100%;
  opacity: 0.6;
}

.select-btn img,
.delete-btn img {
  height: 100%;
}

.select-btn:hover,
.delete-btn:hover {
  opacity: 1;
}

.btn {
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
}

.icon {
  display: flex;
  align-items: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.locked-btn-wrapper {
  position: absolute;
  right: 2vh;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  gap: 0.5vh;
  height: calc(100% - 4vh);
  flex-direction: column;
}

.price-box {
  display: flex;
  align-items: center;
  background: rgba(245, 189, 104, 0.15);
  border-radius: 3px;
  height: calc(50% - 0.25vh);
}

.price-box .title {
  font-weight: 300;
  font-size: 12px;
  line-height: 100%;
  color: #ffffff;
  padding: 0.5vh 1vh;
  width: 40%;
  text-align: center;
}

.price-box .price {
  font-weight: 300;
  font-size: 12px;
  line-height: 100%;
  color: #f5bd68;
  text-shadow: 0px 0px 25px #f5bd68;
  background: rgba(245, 189, 104, 0.15);
  border-radius: 3px;
  padding: 0.5vh 1vh;
  width: 60%;
  text-align: center;
}

.purchase-btn {
  height: calc(50% - 0.25vh);
  cursor: pointer;
  position: relative;
  font-weight: 300;
  font-size: 11px;
  line-height: 100%;
  text-align: center;
  color: #ffffff;
  opacity: 0.8;
}

.purchase-btn img {
  width: 100%;
  height: 100%;
}

.purchase-btn:hover {
  opacity: 1;
}

.purchase-btn span {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
</style>
