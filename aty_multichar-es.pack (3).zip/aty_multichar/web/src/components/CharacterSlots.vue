<script setup>
import SlotBox from './SlotBox.vue'

import { useMenuData } from '@/stores/data'
import { storeToRefs } from 'pinia'

const menuData = useMenuData()
const { characters, slots, purchasedSlots, freeSlots } = storeToRefs(menuData)
</script>

<template>
  <div class="char-slots">
    <div class="header-wrapper">
      <div class="icon-wrapper"><img src="@/assets/slot-icon.png" /></div>
      <div class="title-wrapper">
        <div class="subtitle">Welcome to</div>
        <div class="title">Character Selector</div>
      </div>
    </div>

    <div class="slots-wrapper">
      <template v-for="slot in slots" :key="slot">
        <SlotBox
          :slot="slot"
          :character="characters[slot - 1] || null"
          :isLocked="slot - purchasedSlots > freeSlots"
        />
      </template>
    </div>
  </div>
</template>

<style scoped>
.char-slots {
  width: 23vw;
  height: fit-content;
  display: flex;
  flex-direction: column;
  gap: 3vh;
}

.char-slots .header-wrapper {
  display: flex;
  align-items: center;
  height: 6vh;
  width: 100%;
  gap: 1vw;
}

.char-slots .icon-wrapper {
  width: 6vh;
  height: 6vh;
}

.char-slots .icon-wrapper img {
  width: 100%;
  height: 100%;
}

.char-slots .title-wrapper {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.char-slots .title-wrapper .subtitle {
  font-weight: 275;
  font-size: 24px;
  line-height: 100%;
  color: #5affe7;
  text-shadow: 0px 0px 68px #5affe7;
}

.char-slots .title-wrapper .title {
  font-family: 'Brothership';
  font-weight: 400;
  font-size: 48px;
  line-height: 100%;
  color: #5affe7;
  text-shadow: 0px 0px 68px #5affe7;
}

.char-slots .slots-wrapper {
  display: flex;
  flex-wrap: wrap;
  gap: 1vh;
}
</style>
