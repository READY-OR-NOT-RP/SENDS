import { defineStore } from 'pinia'

export const useMenuData = defineStore('menuData', {
  state: () => {
    return {
      open: false,
      photoMode: false,
      popup: false,
      menu: 'info',
      selectedCharacterIndex: 1,
      selectedCharacter: {},
      characters: [],
      slots: 5,
      freeSlots: 4,
      purchasedSlots: 0,
      slotsPrice: 300
    }
  },

  actions: {
    toggleMenu(val) {
      this.open = val
    },

    setMenu(val) {
      this.menu = val
    },

    togglePopup(val) {
      this.popup = val
    },

    togglePhotoMode(val) {
      this.photoMode = val
    },

    setSelectedCharacter(character, index) {
      this.selectedCharacter = character
      this.selectedCharacterIndex = index
    },

    setSlots(slots) {
      this.slots = slots
    },

    setFreeSlots(slots) {
      this.freeSlots = slots
    },

    setPurchasedSlots(slots) {
      this.purchasedSlots = slots
    },

    setSlotsPrice(price) {
      this.slotsPrice = price
    },

    setCharacters(characters) {
      this.characters = characters
      this.selectedCharacter = characters[0]
    }
  }
})
