import { useMenuData } from '@/stores/data'
import { toDataUrl } from '@/utils'
import { fetchNui } from '@/utils'

export default function () {
  const menuData = useMenuData()

  window.addEventListener('message', ({ data }) => {
    switch (data.action) {
      case 'openMenu':
        menuData.toggleMenu(true)
        menuData.setCharacters(data.characters)
        menuData.setSlots(data.slots)
        menuData.setFreeSlots(data.freeSlots)
        menuData.setSlotsPrice(data.slotsPrice)
        menuData.setPurchasedSlots(data.purchasedSlots)

        break

      case 'setCharacters':
        menuData.setCharacters(data.characters)
        break

      case 'convert_base64':
        toDataUrl(data.img, function (base64) {
          fetchNui('base64', {
            base64: base64,
            handle: data.handle,
            id: data.id
          })
        })
        break

      default:
        break
    }
  })
}
