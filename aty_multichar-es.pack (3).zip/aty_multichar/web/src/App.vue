<script setup>
import CharacterMenu from './components/CharacterMenu.vue'
import CharacterCreation from './components/CharacterCreation.vue'

import nuiEvents from './utils/nui-events'
import { onMounted } from 'vue'

import { useMenuData } from '@/stores/data'
import { storeToRefs } from 'pinia'

const menuData = useMenuData()
const { menu, open } = storeToRefs(menuData)

onMounted(() => {
  nuiEvents()
})
</script>

<template>
  <TransitionGroup name="fade">
    <CharacterMenu v-if="menu === 'info' && open" />
    <CharacterCreation v-if="menu === 'creation' && open" />
  </TransitionGroup>
</template>

<style scoped>
.fade-move,
.fade-enter-active,
.fade-leave-active {
  transition: all 0.5s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.fade-leave-active {
  position: absolute;
}
</style>
